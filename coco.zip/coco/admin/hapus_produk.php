<?php

session_start();

include "../config/database.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: produk.php");
    exit;
}

$id = $_GET['id'];


$query = mysqli_query(
    $conn,
    "SELECT * FROM products WHERE id='$id'"
);

$product = mysqli_fetch_assoc($query);


if ($product) {

    if (!empty($product['gambar'])) {

        $file =
            "../assets/img/produk/" . $product['gambar'];

        if (file_exists($file)) {
            unlink($file);
        }
    }


    mysqli_query(
        $conn,
        "DELETE FROM products WHERE id='$id'"
    );
}


header("Location: produk.php");

exit;

?>