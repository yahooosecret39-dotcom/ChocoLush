<?php

session_start();

include "../config/database.php";


// ========================================
// MENU TERLARIS
// ========================================

$query_menu_terlaris = mysqli_query(
    $conn,
    "SELECT 
        p.id,
        p.nama_produk,
        p.gambar,
        SUM(od.jumlah) AS total_terjual
     FROM order_details od
     INNER JOIN products p
        ON od.product_id = p.id
     INNER JOIN orders o
        ON od.order_id = o.id
     WHERE o.status != 'Dibatalkan'
     GROUP BY p.id, p.nama_produk, p.gambar
     ORDER BY total_terjual DESC
     LIMIT 5"
);

// ========================================
// CEK LOGIN ADMIN
// ========================================

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {

    header("Location: ../login.php");
    exit;

}


// ========================================
// TOTAL PELANGGAN
// ========================================

$query_customer = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM users
     WHERE role='customer'"
);

$data_customer = mysqli_fetch_assoc($query_customer);

$total_customer = $data_customer['total'];


// ========================================
// TOTAL PESANAN
// ========================================

$query_order = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM orders"
);

$data_order = mysqli_fetch_assoc($query_order);

$total_pesanan = $data_order['total'];


// ========================================
// PRODUK TERJUAL
// ========================================

$query_terjual = mysqli_query(
    $conn,
    "SELECT COALESCE(SUM(jumlah), 0) AS total
     FROM order_details"
);

$data_terjual = mysqli_fetch_assoc($query_terjual);

$produk_terjual = $data_terjual['total'];


// ========================================
// PENDAPATAN HARI INI
// ========================================

$query_pendapatan = mysqli_query(
    $conn,
    "SELECT COALESCE(SUM(total_harga), 0) AS total
     FROM orders
     WHERE DATE(tanggal_pesanan) = CURDATE()
     AND status != 'Dibatalkan'"
);

$data_pendapatan = mysqli_fetch_assoc($query_pendapatan);

$pendapatan_hari_ini = $data_pendapatan['total'];


// ========================================
// DATA PRODUK
// ========================================

$query_produk = mysqli_query(
    $conn,
    "SELECT *
     FROM products
     ORDER BY stok ASC"
);





// ========================================
// GRAFIK PENJUALAN 7 HARI
// ========================================

$grafik_data = [];

for ($i = 6; $i >= 0; $i--) {

    $tanggal = date(
        'Y-m-d',
        strtotime("-$i days")
    );

    $query_grafik = mysqli_query(
        $conn,
        "SELECT COALESCE(SUM(total_harga), 0) AS total
         FROM orders
         WHERE DATE(tanggal_pesanan) = '$tanggal'
         AND status != 'Dibatalkan'"
    );

    $data_grafik = mysqli_fetch_assoc($query_grafik);

    $grafik_data[] = [
        'tanggal' => $tanggal,
        'total' => $data_grafik['total']
    ];
}


// Nilai terbesar untuk tinggi grafik

$nilai_maksimal = 0;

foreach ($grafik_data as $data) {

    if ($data['total'] > $nilai_maksimal) {

        $nilai_maksimal = $data['total'];

    }

}

if ($nilai_maksimal == 0) {

    $nilai_maksimal = 1;

}

?>


<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Dashboard Admin - ChocoLush
    </title>


    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >

</head>


<body>


<div class="admin-container">


    <!-- =================================
         SIDEBAR
    ================================= -->

    <aside class="sidebar">

        <h2>
            🍫 ChocoLush
        </h2>


        <a
            href="dashboard.php"
            class="active-menu"
        >
            📊 Dashboard
        </a>


        <a href="produk.php">
            🍫 Produk
        </a>


        <a href="pesanan.php">
            🛒 Pesanan
        </a>


        <a href="#">
            👥 Customer
        </a>


        <a href="#">
            💰 Transaksi
        </a>


        <a href="#">
            📈 Laporan
        </a>


        <a href="../logout.php">
            🚪 Logout
        </a>

    </aside>



    <!-- =================================
         MAIN CONTENT
    ================================= -->

    <main class="admin-content">


        <!-- HEADER -->

        <div class="dashboard-header">

            <div>

                <h1>
                    Dashboard
                </h1>

                <p>
                    Selamat datang kembali,
                    <b><?php echo htmlspecialchars($_SESSION['nama']); ?></b> 👋
                </p>

            </div>


            <div class="dashboard-date">

                📅
                <?php echo date('d F Y'); ?>

            </div>

        </div>



        <!-- =================================
             STATISTIK
        ================================= -->

        <div class="stat-grid">


            <!-- TOTAL PESANAN -->

            <div class="stat-card">

                <div class="stat-icon pink">
                    🛒
                </div>

                <p>
                    Total Pesanan
                </p>

                <h2>
                    <?php echo number_format($total_pesanan); ?>
                </h2>

                <small>
                    Semua pesanan
                </small>

            </div>



            <!-- PRODUK TERJUAL -->

            <div class="stat-card">

                <div class="stat-icon cream">
                    🍫
                </div>

                <p>
                    Produk Terjual
                </p>

                <h2>
                    <?php echo number_format($produk_terjual); ?>
                </h2>

                <small>
                    Total produk terjual
                </small>

            </div>



            <!-- CUSTOMER -->

            <div class="stat-card">

                <div class="stat-icon purple">
                    👥
                </div>

                <p>
                    Total Pelanggan
                </p>

                <h2>
                    <?php echo number_format($total_customer); ?>
                </h2>

                <small>
                    Customer terdaftar
                </small>

            </div>



            <!-- PENDAPATAN -->

            <div class="stat-card">

                <div class="stat-icon green">
                    💰
                </div>

                <p>
                    Pendapatan Hari Ini
                </p>

                <h2>
                    Rp <?php echo number_format(
                        $pendapatan_hari_ini,
                        0,
                        ',',
                        '.'
                    ); ?>
                </h2>

                <small>
                    Pesanan hari ini
                </small>

            </div>


        </div>



        <!-- =================================
             GRAFIK + MENU FAVORIT
        ================================= -->

        <div class="dashboard-middle">


            <!-- GRAFIK -->

            <div class="dashboard-box chart-box">

                <div class="box-header">

                    <h2>
                        Grafik Penjualan
                    </h2>

                    <span>
                        7 Hari Terakhir
                    </span>

                </div>


                <div class="chart">

                    <?php foreach ($grafik_data as $data) { ?>


                        <?php

                        $tinggi =
                            ($data['total'] / $nilai_maksimal) * 100;

                        if ($tinggi < 5 && $data['total'] > 0) {

                            $tinggi = 5;

                        }

                        $hari = date(
                            'D',
                            strtotime($data['tanggal'])
                        );

                        ?>


                        <div class="chart-column">


                            <div
                                class="chart-value"
                                style="height: <?php echo $tinggi; ?>%;"
                            >

                                <?php if ($data['total'] > 0) { ?>

                                    <span>

                                        Rp
                                        <?php echo number_format(
                                            $data['total'] / 1000,
                                            0,
                                            ',',
                                            '.'
                                        ); ?>K

                                    </span>

                                <?php } ?>

                            </div>


                            <small>
                                <?php echo $hari; ?>
                            </small>


                            <small>
                                <?php echo date(
                                    'd/m',
                                    strtotime($data['tanggal'])
                                ); ?>
                            </small>


                        </div>


                    <?php } ?>

                </div>

            </div>



   <!-- MENU TERLARIS -->

<div class="dashboard-box favorite-box">

    <div class="box-header">

        <h2>
            ⭐ Menu Terlaris
        </h2>

        <a href="produk.php">
            Lihat Semua →
        </a>

    </div>


    <div class="favorite-list">

        <?php if (mysqli_num_rows($query_menu_terlaris) > 0) { ?>

            <?php while ($terlaris = mysqli_fetch_assoc($query_menu_terlaris)) { ?>

                <div class="favorite-item">


                    <!-- GAMBAR PRODUK -->

                    <div class="favorite-image">

                        <?php if (!empty($terlaris['gambar'])) { ?>

                            <img
                                src="../assets/img/produk/<?php echo htmlspecialchars($terlaris['gambar']); ?>"
                                alt="<?php echo htmlspecialchars($terlaris['nama_produk']); ?>"
                            >

                        <?php } else { ?>

                            🍫

                        <?php } ?>

                    </div>


                    <!-- INFORMASI PRODUK -->

                    <div class="favorite-info">

                        <h3>

                            <?php echo htmlspecialchars(
                                $terlaris['nama_produk']
                            ); ?>

                        </h3>


                        <small>

                            <?php echo $terlaris['total_terjual']; ?>

                            terjual

                        </small>

                    </div>


                    <span>
                        ›
                    </span>


                </div>

            <?php } ?>


        <?php } else { ?>


            <div class="no-data">

                ⭐

                <p>
                    Belum ada data penjualan.
                </p>

            </div>


        <?php } ?>

    </div>

</div>



        <!-- =================================
             STOK PRODUK
        ================================= -->

        <div class="dashboard-box stock-box">


            <div class="box-header">

                <div>

                    <h2>
                        📦 Stok Produk
                    </h2>

                    <p>
                        Produk dengan stok paling sedikit
                    </p>

                </div>


                <a href="produk.php">
                    Kelola Produk →
                </a>

            </div>



            <div class="stock-table">

                <table>

                    <thead>

                        <tr>

                            <th>
                                Produk
                            </th>

                            <th>
                                Harga
                            </th>

                            <th>
                                Stok
                            </th>

                            <th>
                                Status
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                    <?php

                    while (
                        $produk =
                        mysqli_fetch_assoc($query_produk)
                    ) {

                    ?>


                        <tr>


                            <td>

                                <div class="stock-product">

                                    <div class="stock-image">

                                        <?php if (!empty($produk['gambar'])) { ?>

                                            <img
                                                src="../assets/img/produk/<?php echo htmlspecialchars($produk['gambar']); ?>"
                                            >

                                        <?php } else { ?>

                                            🍫

                                        <?php } ?>

                                    </div>


                                    <b>

                                        <?php echo htmlspecialchars(
                                            $produk['nama_produk']
                                        ); ?>

                                    </b>

                                </div>

                            </td>


                            <td>

                                Rp <?php echo number_format(
                                    $produk['harga'],
                                    0,
                                    ',',
                                    '.'
                                ); ?>

                            </td>


                            <td>

                                <b>
                                    <?php echo $produk['stok']; ?>
                                </b>

                            </td>


                            <td>


                                <?php

                                if ($produk['stok'] <= 5) {

                                ?>

                                    <span class="stock-danger">
                                        Stok Menipis
                                    </span>

                                <?php

                                } elseif ($produk['stok'] <= 10) {

                                ?>

                                    <span class="stock-warning">
                                        Perlu Restock
                                    </span>

                                <?php

                                } else {

                                ?>

                                    <span class="stock-safe">
                                        Tersedia
                                    </span>

                                <?php } ?>


                            </td>


                        </tr>


                    <?php } ?>


                    </tbody>

                </table>

            </div>


        </div>


    </main>

</div>


</body>

</html>