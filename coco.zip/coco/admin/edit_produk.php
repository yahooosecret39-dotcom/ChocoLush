<?php

session_start();

include "../config/database.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

if (isset($_POST['tambah'])) {

    $nama_produk = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $deskripsi = $_POST['deskripsi'];

    $gambar = "";

    if (!empty($_FILES['gambar']['name'])) {

        $nama_gambar = $_FILES['gambar']['name'];
        $tmp_gambar = $_FILES['gambar']['tmp_name'];

        $gambar = time() . "_" . $nama_gambar;

        move_uploaded_file(
            $tmp_gambar,
            "../assets/img/produk/" . $gambar
        );
    }

    $query = "INSERT INTO products
              (nama_produk, harga, stok, gambar, deskripsi)
              VALUES
              ('$nama_produk', '$harga', '$stok', '$gambar', '$deskripsi')";

    mysqli_query($conn, $query);

    header("Location: produk.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tambah Produk - ChocoLush</title>

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<div class="admin-container">

    <aside class="sidebar">

        <h2>🍫 ChocoLush</h2>

        <a href="dashboard.php">Dashboard</a>

        <a href="produk.php">Produk</a>

        <a href="#">Pesanan</a>

        <a href="#">Customer</a>

        <a href="#">Transaksi</a>

        <a href="#">Laporan</a>

        <a href="../logout.php">Logout</a>

    </aside>


    <main class="admin-content">

        <div class="form-box">

            <h1>Tambah Produk</h1>

            <p>Masukkan informasi produk ChocoLush.</p>


            <form method="POST" enctype="multipart/form-data">

                <label>Nama Produk</label>

                <input
                    type="text"
                    name="nama_produk"
                    placeholder="Contoh: Choco Brownies"
                    required
                >


                <label>Harga</label>

                <input
                    type="number"
                    name="harga"
                    placeholder="Contoh: 25000"
                    required
                >


                <label>Stok</label>

                <input
                    type="number"
                    name="stok"
                    placeholder="Contoh: 20"
                    required
                >


                <label>Gambar Produk</label>

                <input
                    type="file"
                    name="gambar"
                    accept="image/*"
                >


                <label>Deskripsi</label>

                <textarea
                    name="deskripsi"
                    placeholder="Masukkan deskripsi produk"
                    required
                ></textarea>


                <div class="form-button">

                    <a href="produk.php" class="btn-kembali">
                        Kembali
                    </a>

                    <button
                        type="submit"
                        name="tambah"
                        class="btn-simpan"
                    >
                        Simpan Produk
                    </button>

                </div>

            </form>

        </div>

    </main>

</div>

</body>

</html>