<?php

session_start();

include "../config/database.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$products = mysqli_query($conn, "SELECT * FROM products ORDER BY id DESC");

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Produk - ChocoLush</title>

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<div class="admin-container">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <h2>🍫 ChocoLush</h2>

        <a href="dashboard.php">Dashboard</a>

        <a href="produk.php">Produk</a>

        <a href="#">Pesanan</a>

        <a href="#">Customer</a>

        <a href="#">Transaksi</a>

        <a href="#">Laporan</a>

        <a href="../logout.php">Logout</a>

    </aside>


    <!-- CONTENT -->

    <main class="admin-content">

        <div class="page-header">

            <div>
                <h1>Kelola Produk</h1>
                <p>Daftar produk ChocoLush</p>
            </div>

            <a href="tambah_produk.php" class="btn-tambah">
                + Tambah Produk
            </a>

        </div>


        <div class="table-box">

            <table>

                <thead>

                    <tr>

                        <th>No</th>

                        <th>Gambar</th>

                        <th>Nama Produk</th>

                        <th>Harga</th>

                        <th>Stok</th>

                        <th>Deskripsi</th>

                        <th>Aksi</th>

                    </tr>

                </thead>

                <tbody>

                <?php

                $no = 1;

                while ($product = mysqli_fetch_assoc($products)) {

                ?>

                    <tr>

                        <td>
                            <?php echo $no++; ?>
                        </td>

                        <td>

                            <?php if (!empty($product['gambar'])) { ?>

                                <img
                                    src="../assets/img/produk/<?php echo $product['gambar']; ?>"
                                    class="product-table-img"
                                >

                            <?php } else { ?>

                                <span>🍫</span>

                            <?php } ?>

                        </td>

                        <td>
                            <?php echo htmlspecialchars($product['nama_produk']); ?>
                        </td>

                        <td>
                            Rp <?php echo number_format($product['harga'], 0, ',', '.'); ?>
                        </td>

                        <td>
                            <?php echo $product['stok']; ?>
                        </td>

                        <td>
                            <?php echo htmlspecialchars($product['deskripsi']); ?>
                        </td>

                        <td>

                            <a
                                href="edit_produk.php?id=<?php echo $product['id']; ?>"
                                class="btn-edit"
                            >
                                Edit
                            </a>

                            <a
                                href="hapus_produk.php?id=<?php echo $product['id']; ?>"
                                class="btn-hapus"
                                onclick="return confirm('Yakin ingin menghapus produk ini?')"
                            >
                                Hapus
                            </a>

                        </td>

                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </main>

</div>

</body>

</html>