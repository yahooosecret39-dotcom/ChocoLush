<?php

session_start();

include "config/database.php";

if (isset($_POST['login'])) {

    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $query = mysqli_query(
        $conn,
        "SELECT * FROM users
         WHERE email='$email'
         AND password='$password'"
    );

    $data = mysqli_fetch_assoc($query);

    if ($data) {

        $_SESSION['id'] = $data['id'];
        $_SESSION['nama'] = $data['nama'];
        $_SESSION['email'] = $data['email'];
        $_SESSION['role'] = $data['role'];

        if ($data['role'] == 'admin') {

            header("Location: admin/dashboard.php");

        } else {

            header("Location: user/user.php");

        }

        exit;

    } else {

        $error = "Email atau password salah!";

    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login - ChocoLush</title>

    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="auth-container">

    <div class="auth-box">

        <h1>🍫 ChocoLush</h1>

        <h2>Masuk</h2>

        <?php if (isset($error)) { ?>

            <p class="error">
                <?php echo $error; ?>
            </p>

        <?php } ?>

        <form method="POST">

            <input
                type="email"
                name="email"
                placeholder="Email"
                required
            >

            <input
                type="password"
                name="password"
                placeholder="Password"
                required
            >

            <button type="submit" name="login">
                Masuk
            </button>

        </form>

        <p>
            Belum punya akun?
            <a href="register.php">Daftar</a>
        </p>

    </div>

</div>

</body>

</html>