<?php
include "config/database.php";

if (isset($_POST['register'])) {

    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $cek = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

    if (mysqli_num_rows($cek) > 0) {

        $error = "Email sudah digunakan!";

    } else {

        $query = "INSERT INTO users (nama, email, password, role)
                  VALUES ('$nama', '$email', '$password', 'customer')";

        if (mysqli_query($conn, $query)) {

            header("Location: login.php");
            exit;

        } else {

            $error = "Registrasi gagal!";

        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Register - ChocoLush</title>

    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="auth-container">

    <div class="auth-box">

        <h1>🍫 ChocoLush</h1>

        <h2>Daftar Akun</h2>

        <?php if (isset($error)) { ?>

            <p class="error">
                <?php echo $error; ?>
            </p>

        <?php } ?>

        <form method="POST">

            <input
                type="text"
                name="nama"
                placeholder="Nama Lengkap"
                required
            >

            <input
                type="email"
                name="email"
                placeholder="Email"
                required
            >

            <input
                type="password"
                name="password"
                placeholder="Password"
                required
            >

            <button type="submit" name="register">
                Daftar
            </button>

        </form>

        <p>
            Sudah punya akun?
            <a href="login.php">Login</a>
        </p>

    </div>

</div>

</body>
</html>