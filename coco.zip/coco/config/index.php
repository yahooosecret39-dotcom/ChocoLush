<?php
session_start();

if (isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'admin') {
        header("Location: admin/dashboard.php");
        exit;
    } else {
        header("Location: user/user.php");
        exit;
    }

}

header("Location: login.php");
exit;
?>