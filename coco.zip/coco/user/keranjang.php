<?php

session_start();

include "../config/database.php";


// Cek apakah customer sudah login
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {

    header("Location: ../login.php");
    exit;

}


// Jika keranjang belum ada
if (!isset($_SESSION['keranjang'])) {

    $_SESSION['keranjang'] = [];

}


// ========================================
// UPDATE JUMLAH PRODUK
// ========================================

if (isset($_POST['update_keranjang'])) {

    foreach ($_POST['jumlah'] as $id => $jumlah) {

        $id = intval($id);
        $jumlah = intval($jumlah);


        // Ambil stok produk
        $query = mysqli_query(
            $conn,
            "SELECT stok FROM products WHERE id='$id'"
        );

        $product = mysqli_fetch_assoc($query);


        if ($product) {

            $stok = intval($product['stok']);


            // Jika jumlah kurang dari 1
            if ($jumlah < 1) {

                unset($_SESSION['keranjang'][$id]);

            }

            // Jika jumlah lebih dari stok
            elseif ($jumlah > $stok) {

                $_SESSION['keranjang'][$id] = $stok;

            }

            // Jumlah normal
            else {

                $_SESSION['keranjang'][$id] = $jumlah;

            }

        }

    }


    header("Location: keranjang.php");
    exit;

}


// ========================================
// HAPUS PRODUK
// ========================================

if (isset($_GET['hapus'])) {

    $id = intval($_GET['hapus']);

    unset($_SESSION['keranjang'][$id]);

    header("Location: keranjang.php");
    exit;

}


// ========================================
// KOSONGKAN KERANJANG
// ========================================

if (isset($_GET['kosongkan'])) {

    $_SESSION['keranjang'] = [];

    header("Location: keranjang.php");
    exit;

}


// ========================================
// AMBIL DATA KERANJANG
// ========================================

$cartProducts = [];

$total = 0;


if (!empty($_SESSION['keranjang'])) {

    $ids = array_keys($_SESSION['keranjang']);

    $ids = array_map('intval', $ids);

    $idList = implode(',', $ids);


    $query = mysqli_query(
        $conn,
        "SELECT * FROM products
         WHERE id IN ($idList)"
    );


    while ($product = mysqli_fetch_assoc($query)) {

        $id = $product['id'];

        $jumlah = $_SESSION['keranjang'][$id];


        // Pastikan jumlah tidak melebihi stok
        if ($jumlah > $product['stok']) {

            $jumlah = $product['stok'];

            $_SESSION['keranjang'][$id] = $jumlah;

        }


        // Jika stok 0
        if ($product['stok'] <= 0) {

            unset($_SESSION['keranjang'][$id]);

            continue;

        }


        $subtotal = $product['harga'] * $jumlah;

        $total += $subtotal;


        $product['jumlah'] = $jumlah;

        $product['subtotal'] = $subtotal;


        $cartProducts[] = $product;

    }

}

?>

<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Keranjang - ChocoLush
    </title>


    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >

</head>


<body>


<!-- =========================
     NAVBAR
========================= -->

<nav class="navbar">

    <div class="logo">
        🍫 ChocoLush
    </div>


    <div class="menu">

        <a href="user.php">
            Home
        </a>

        <a href="user.php#produk">
            Produk
        </a>

        <a href="keranjang.php">
            🛒 Keranjang
        </a>

        <a href="pesanan.php">
            📦 Pesanan Saya
        </a>

        <a href="#">
            Profile
        </a>

        <a href="../logout.php">
            Logout
        </a>

    </div>

</nav>



<!-- =========================
     KERANJANG
========================= -->

<section class="cart-section">


    <div class="cart-container">


        <div class="cart-title">

            <div>

                <h1>
                    Keranjang Belanja 🛒
                </h1>

                <p>
                    Periksa kembali produk yang ingin kamu beli.
                </p>

            </div>


            <?php if (!empty($cartProducts)) { ?>

                <a
                    href="keranjang.php?kosongkan=1"
                    class="btn-clear-cart"
                    onclick="return confirm('Yakin ingin mengosongkan keranjang?')"
                >
                    🗑️ Kosongkan Keranjang
                </a>

            <?php } ?>

        </div>



        <?php if (empty($cartProducts)) { ?>


            <!-- KERANJANG KOSONG -->

            <div class="empty-cart">

                <div class="empty-cart-icon">
                    🛒
                </div>

                <h2>
                    Keranjang masih kosong
                </h2>

                <p>
                    Yuk pilih produk ChocoLush favoritmu!
                </p>

                <a
                    href="user.php#produk"
                    class="btn-shopping"
                >
                    Mulai Belanja
                </a>

            </div>


        <?php } else { ?>


            <!-- =========================
                 FORM KERANJANG
            ========================= -->

            <form
                method="POST"
                action="keranjang.php"
            >


                <div class="cart-content">


                    <!-- DAFTAR PRODUK -->

                    <div class="cart-list">


                        <?php foreach ($cartProducts as $product) { ?>


                            <div class="cart-item">


                                <!-- GAMBAR -->

                                <div class="cart-image">

                                    <?php if (!empty($product['gambar'])) { ?>

                                        <img
                                            src="../assets/img/produk/<?php echo htmlspecialchars($product['gambar']); ?>"
                                            alt="<?php echo htmlspecialchars($product['nama_produk']); ?>"
                                        >

                                    <?php } else { ?>

                                        🍫

                                    <?php } ?>

                                </div>



                                <!-- INFORMASI -->

                                <div class="cart-info">

                                    <h3>

                                        <?php echo htmlspecialchars(
                                            $product['nama_produk']
                                        ); ?>

                                    </h3>


                                    <p class="cart-price">

                                        Rp <?php echo number_format(
                                            $product['harga'],
                                            0,
                                            ',',
                                            '.'
                                        ); ?>

                                    </p>


                                    <p class="cart-stock">

                                        Stok:
                                        <?php echo $product['stok']; ?>

                                    </p>

                                </div>



                                <!-- JUMLAH -->

                                <div class="cart-quantity">

                                    <label>
                                        Jumlah
                                    </label>

                                    <input
                                        type="number"
                                        name="jumlah[<?php echo $product['id']; ?>]"
                                        value="<?php echo $product['jumlah']; ?>"
                                        min="1"
                                        max="<?php echo $product['stok']; ?>"
                                    >

                                </div>



                                <!-- SUBTOTAL -->

                                <div class="cart-subtotal">

                                    <span>
                                        Subtotal
                                    </span>

                                    <strong>

                                        Rp <?php echo number_format(
                                            $product['subtotal'],
                                            0,
                                            ',',
                                            '.'
                                        ); ?>

                                    </strong>

                                </div>



                                <!-- HAPUS -->

                                <a
                                    href="keranjang.php?hapus=<?php echo $product['id']; ?>"
                                    class="btn-remove"
                                    onclick="return confirm('Hapus produk ini dari keranjang?')"
                                >
                                    🗑️
                                </a>


                            </div>


                        <?php } ?>


                    </div>



                    <!-- =========================
                         RINGKASAN
                    ========================= -->

                    <div class="cart-summary">

                        <h2>
                            Ringkasan Belanja
                        </h2>


                        <div class="summary-row">

                            <span>
                                Total Produk
                            </span>

                            <span>

                                <?php

                                $totalProduk = 0;

                                foreach ($cartProducts as $product) {

                                    $totalProduk += $product['jumlah'];

                                }

                                echo $totalProduk;

                                ?>

                                item

                            </span>

                        </div>


                        <div class="summary-row">

                            <span>
                                Total Harga
                            </span>

                            <strong>

                                Rp <?php echo number_format(
                                    $total,
                                    0,
                                    ',',
                                    '.'
                                ); ?>

                            </strong>

                        </div>


                        <hr>


                        <div class="summary-total">

                            <span>
                                Total
                            </span>

                            <strong>

                                Rp <?php echo number_format(
                                    $total,
                                    0,
                                    ',',
                                    '.'
                                ); ?>

                            </strong>

                        </div>


                        <button
                            type="submit"
                            name="update_keranjang"
                            class="btn-update-cart"
                        >
                            🔄 Update Keranjang
                        </button>


                        <a
                            href="checkout.php"
                            class="btn-checkout"
                        >
                            💳 Lanjut ke Checkout
                        </a>


                    </div>


                </div>


            </form>


        <?php } ?>


    </div>

</section>



<!-- FOOTER -->

<footer class="footer">

    <h3>
        🍫 ChocoLush
    </h3>

    <p>
        Sweet Chocolate For Every Moment
    </p>

    <p>
        © 2026 ChocoLush
    </p>

</footer>


</body>

</html>