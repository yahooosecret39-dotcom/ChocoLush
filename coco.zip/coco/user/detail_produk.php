<?php

session_start();

include "../config/database.php";


// Cek apakah customer sudah login
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {

    header("Location: ../login.php");
    exit;

}


// Cek ID produk
if (!isset($_GET['id'])) {

    header("Location: user.php");
    exit;

}


$id = intval($_GET['id']);


// Ambil data produk
$query = mysqli_query(
    $conn,
    "SELECT * FROM products WHERE id='$id'"
);

$product = mysqli_fetch_assoc($query);


// Jika produk tidak ditemukan
if (!$product) {

    echo "Produk tidak ditemukan.";
    exit;

}


// ========================================
// TAMBAH KE KERANJANG
// ========================================

if (isset($_POST['tambah_keranjang'])) {

    $jumlah = intval($_POST['jumlah']);

    // Minimal jumlah 1
    if ($jumlah < 1) {
        $jumlah = 1;
    }

    // Tidak boleh melebihi stok
    if ($jumlah > $product['stok']) {
        $jumlah = $product['stok'];
    }


    // Buat session keranjang jika belum ada
    if (!isset($_SESSION['keranjang'])) {

        $_SESSION['keranjang'] = [];

    }


    // Jika produk sudah ada di keranjang
    if (isset($_SESSION['keranjang'][$id])) {

        $_SESSION['keranjang'][$id] += $jumlah;

    } else {

        $_SESSION['keranjang'][$id] = $jumlah;

    }


    // Kembali ke halaman produk
    header("Location: user.php?berhasil=1");
    exit;

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>
        <?php echo htmlspecialchars($product['nama_produk']); ?>
        - ChocoLush
    </title>

    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >

</head>


<body>


<!-- NAVBAR -->

<nav class="navbar">

    <div class="logo">
        🍫 ChocoLush
    </div>


    <div class="menu">

        <a href="user.php">
            Home
        </a>

        <a href="user.php">
            Produk
        </a>

        <a href="keranjang.php">
            Keranjang 🛒
        </a>

        <a href="#">
            Profile
        </a>

        <a href="../logout.php">
            Logout
        </a>

    </div>

</nav>



<!-- DETAIL PRODUK -->

<section class="detail-section">

    <div class="detail-container">


        <!-- GAMBAR -->

        <div class="detail-image">

            <?php if (!empty($product['gambar'])) { ?>

                <img
                    src="../assets/img/produk/<?php echo htmlspecialchars($product['gambar']); ?>"
                    alt="<?php echo htmlspecialchars($product['nama_produk']); ?>"
                >

            <?php } else { ?>

                <div class="no-image">
                    🍫
                </div>

            <?php } ?>

        </div>



        <!-- INFORMASI PRODUK -->

        <div class="detail-info">

            <p class="detail-label">
                CHOCOLUSH PRODUCT
            </p>


            <h1>
                <?php echo htmlspecialchars($product['nama_produk']); ?>
            </h1>


            <h2 class="detail-price">
                Rp <?php echo number_format(
                    $product['harga'],
                    0,
                    ',',
                    '.'
                ); ?>
            </h2>


            <p class="detail-description">
                <?php echo nl2br(
                    htmlspecialchars($product['deskripsi'])
                ); ?>
            </p>


            <p class="detail-stock">

                Stok tersedia:
                <b>
                    <?php echo $product['stok']; ?>
                </b>

            </p>



            <!-- FORM KERANJANG -->

            <?php if ($product['stok'] > 0) { ?>

                <form
                    method="POST"
                    class="cart-form"
                >

                    <label>
                        Jumlah
                    </label>


                    <input
                        type="number"
                        name="jumlah"
                        value="1"
                        min="1"
                        max="<?php echo $product['stok']; ?>"
                        required
                    >


                    <button
                        type="submit"
                        name="tambah_keranjang"
                        class="btn-cart"
                    >
                        🛒 Tambah ke Keranjang
                    </button>

                </form>

            <?php } else { ?>

                <button
                    class="btn-habis"
                    disabled
                >
                    Stok Habis
                </button>

            <?php } ?>


            <br>


            <a
                href="user.php"
                class="btn-kembali-user"
            >
                ← Kembali ke Produk
            </a>

        </div>

    </div>

</section>


</body>

</html>