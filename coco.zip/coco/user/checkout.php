<?php

session_start();

include "../config/database.php";


// ========================================
// CEK LOGIN CUSTOMER
// ========================================

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {

    header("Location: ../login.php");
    exit;

}


// ========================================
// CEK KERANJANG
// ========================================

if (!isset($_SESSION['keranjang']) || empty($_SESSION['keranjang'])) {

    header("Location: keranjang.php");
    exit;

}


// ========================================
// AMBIL ID USER
// ========================================

$user_id = $_SESSION['id'];


// ========================================
// AMBIL DATA KERANJANG
// ========================================

$cartProducts = [];

$total = 0;

$ids = array_keys($_SESSION['keranjang']);

$ids = array_map('intval', $ids);

$idList = implode(',', $ids);


$query = mysqli_query(
    $conn,
    "SELECT *
     FROM products
     WHERE id IN ($idList)"
);


while ($product = mysqli_fetch_assoc($query)) {

    $id = $product['id'];

    $jumlah = intval($_SESSION['keranjang'][$id]);

    $stok = intval($product['stok']);


    // Cek stok

    if ($jumlah > $stok) {

        $jumlah = $stok;

    }


    if ($jumlah <= 0) {

        continue;

    }


    $subtotal = $product['harga'] * $jumlah;

    $total += $subtotal;


    $product['jumlah'] = $jumlah;

    $product['subtotal'] = $subtotal;


    $cartProducts[] = $product;

}


// Jika tidak ada produk

if (empty($cartProducts)) {

    header("Location: keranjang.php");

    exit;

}


// ========================================
// PROSES CHECKOUT
// ========================================

$error = "";


if (isset($_POST['checkout'])) {

    $alamat = trim($_POST['alamat']);

    $metode_pembayaran = $_POST['metode_pembayaran'];


    // Validasi alamat

    if (empty($alamat)) {

        $error = "Alamat pengiriman wajib diisi.";

    }

    // Validasi pembayaran

    elseif (empty($metode_pembayaran)) {

        $error = "Silakan pilih metode pembayaran.";

    }

    else {


        // ========================================
        // MULAI TRANSAKSI DATABASE
        // ========================================

        mysqli_begin_transaction($conn);


        try {


            // ========================================
            // SIMPAN PESANAN
            // ========================================

            $alamat = mysqli_real_escape_string(
                $conn,
                $alamat
            );


            $metode_pembayaran = mysqli_real_escape_string(
                $conn,
                $metode_pembayaran
            );


            $query_order = mysqli_query(
                $conn,

                "INSERT INTO orders
                (
                    user_id,
                    alamat,
                    metode_pembayaran,
                    total_harga,
                    status
                )

                VALUES
                (
                    '$user_id',
                    '$alamat',
                    '$metode_pembayaran',
                    '$total',
                    'Menunggu'
                )"
            );


            if (!$query_order) {

                throw new Exception(
                    "Gagal menyimpan pesanan."
                );

            }


            // Ambil ID pesanan

            $order_id = mysqli_insert_id($conn);


            // ========================================
            // SIMPAN DETAIL PESANAN
            // ========================================

            foreach ($cartProducts as $product) {

                $product_id = $product['id'];

                $jumlah = $product['jumlah'];

                $harga = $product['harga'];

                $subtotal = $product['subtotal'];


                $query_detail = mysqli_query(
                    $conn,

                    "INSERT INTO order_details
                    (
                        order_id,
                        product_id,
                        jumlah,
                        harga,
                        subtotal
                    )

                    VALUES
                    (
                        '$order_id',
                        '$product_id',
                        '$jumlah',
                        '$harga',
                        '$subtotal'
                    )"
                );


                if (!$query_detail) {

                    throw new Exception(
                        "Gagal menyimpan detail pesanan."
                    );

                }


                // ========================================
                // KURANGI STOK PRODUK
                // ========================================

                $query_stok = mysqli_query(
                    $conn,

                    "UPDATE products

                     SET stok = stok - $jumlah

                     WHERE id = '$product_id'
                     AND stok >= $jumlah"
                );


                if (!$query_stok) {

                    throw new Exception(
                        "Gagal memperbarui stok."
                    );

                }


                if (mysqli_affected_rows($conn) == 0) {

                    throw new Exception(
                        "Stok produk tidak mencukupi."
                    );

                }

            }


            // ========================================
            // SIMPAN SEMUA PERUBAHAN
            // ========================================

            mysqli_commit($conn);


            // Kosongkan keranjang

            $_SESSION['keranjang'] = [];


            // Simpan nomor pesanan

            $_SESSION['pesanan_berhasil'] = $order_id;


            // Pindah ke halaman sukses

            header(
                "Location: checkout.php?success=1&order=$order_id"
            );

            exit;


        } catch (Exception $e) {


            // Batalkan transaksi

            mysqli_rollback($conn);


            $error = $e->getMessage();

        }

    }

}


// ========================================
// CEK CHECKOUT BERHASIL
// ========================================

$success = isset($_GET['success']);

$order_id_success = $_GET['order'] ?? '';

?>


<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Checkout - ChocoLush
    </title>


    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >

</head>


<body>


<!-- ========================================
     NAVBAR
======================================== -->

<nav class="navbar">

    <div class="logo">
        🍫 ChocoLush
    </div>


    <div class="menu">

        <a href="user.php">
            Home
        </a>

        <a href="user.php#produk">
            Produk
        </a>

        <a href="keranjang.php">
            🛒 Keranjang
        </a>

        <a href="../logout.php">
            Logout
        </a>

    </div>

</nav>



<!-- ========================================
     CHECKOUT
======================================== -->

<section class="checkout-section">


    <div class="checkout-container">


        <?php if ($success) { ?>


            <!-- =================================
                 PESANAN BERHASIL
            ================================= -->

            <div class="checkout-success">

                <div class="success-icon">
                    ✓
                </div>


                <h1>
                    Pesanan Berhasil! 🎉
                </h1>


                <p>
                    Terima kasih telah berbelanja
                    di ChocoLush.
                </p>


                <div class="order-number">

                    Nomor Pesanan

                    <strong>
                        #<?php echo htmlspecialchars($order_id_success); ?>
                    </strong>

                </div>


                <p>
                    Pesanan kamu sedang menunggu
                    diproses oleh admin.
                </p>


                <div class="success-buttons">

                    <a
                        href="user.php"
                        class="btn-checkout"
                    >
                        🍫 Kembali Belanja
                    </a>


                    <a
                        href="keranjang.php"
                        class="btn-shopping"
                    >
                        🏠 Kembali ke Keranjang
                    </a>

                </div>

            </div>


        <?php } else { ?>


            <!-- =================================
                 JUDUL
            ================================= -->

            <div class="checkout-title">

                <h1>
                    Checkout 🛒
                </h1>

                <p>
                    Lengkapi data pengiriman
                    sebelum membuat pesanan.
                </p>

            </div>



            <?php if (!empty($error)) { ?>

                <div class="checkout-error">

                    ⚠️
                    <?php echo htmlspecialchars($error); ?>

                </div>

            <?php } ?>



            <form
                method="POST"
                action="checkout.php"
            >


                <div class="checkout-grid">


                    <!-- =================================
                         DATA PENGIRIMAN
                    ================================= -->

                    <div class="checkout-card">

                        <h2>
                            📍 Alamat Pengiriman
                        </h2>


                        <label>
                            Alamat Lengkap
                        </label>


                        <textarea
                            name="alamat"
                            rows="6"
                            placeholder="Masukkan alamat lengkap pengiriman..."
                            required
                        ></textarea>



                        <h2 class="payment-title">
                            💳 Metode Pembayaran
                        </h2>


                        <label class="payment-option">

                            <input
                                type="radio"
                                name="metode_pembayaran"
                                value="COD"
                                required
                            >

                            <span>

                                <strong>
                                    COD
                                </strong>

                                <small>
                                    Bayar di tempat
                                </small>

                            </span>

                        </label>


                        <label class="payment-option">

                            <input
                                type="radio"
                                name="metode_pembayaran"
                                value="Transfer Bank"
                            >

                            <span>

                                <strong>
                                    Transfer Bank
                                </strong>

                                <small>
                                    Transfer melalui rekening bank
                                </small>

                            </span>

                        </label>


                        <label class="payment-option">

                            <input
                                type="radio"
                                name="metode_pembayaran"
                                value="E-Wallet"
                            >

                            <span>

                                <strong>
                                    E-Wallet
                                </strong>

                                <small>
                                    GoPay / OVO / DANA
                                </small>

                            </span>

                        </label>

                    </div>



                    <!-- =================================
                         RINGKASAN PESANAN
                    ================================= -->

                    <div class="checkout-card order-summary">

                        <h2>
                            🧾 Ringkasan Pesanan
                        </h2>


                        <?php foreach ($cartProducts as $product) { ?>


                            <div class="checkout-product">


                                <div class="checkout-product-image">


                                    <?php if (!empty($product['gambar'])) { ?>

                                        <img
                                            src="../assets/img/produk/<?php echo htmlspecialchars($product['gambar']); ?>"
                                        >

                                    <?php } else { ?>

                                        🍫

                                    <?php } ?>


                                </div>


                                <div class="checkout-product-info">

                                    <h3>

                                        <?php echo htmlspecialchars(
                                            $product['nama_produk']
                                        ); ?>

                                    </h3>


                                    <p>

                                        <?php echo $product['jumlah']; ?>
                                        ×
                                        Rp
                                        <?php echo number_format(
                                            $product['harga'],
                                            0,
                                            ',',
                                            '.'
                                        ); ?>

                                    </p>

                                </div>


                                <strong>

                                    Rp
                                    <?php echo number_format(
                                        $product['subtotal'],
                                        0,
                                        ',',
                                        '.'
                                    ); ?>

                                </strong>


                            </div>


                        <?php } ?>


                        <hr>


                        <div class="checkout-total">

                            <span>
                                Total Pembayaran
                            </span>


                            <strong>

                                Rp
                                <?php echo number_format(
                                    $total,
                                    0,
                                    ',',
                                    '.'
                                ); ?>

                            </strong>

                        </div>


                        <button
                            type="submit"
                            name="checkout"
                            class="btn-order"
                        >
                            🛍️ Buat Pesanan
                        </button>


                        <a
                            href="keranjang.php"
                            class="back-cart"
                        >
                            ← Kembali ke Keranjang
                        </a>

                    </div>


                </div>


            </form>


        <?php } ?>


    </div>

</section>


</body>

</html>