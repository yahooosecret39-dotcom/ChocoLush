<?php
session_start();
include "../config/database.php";

// ========================================
// CEK LOGIN CUSTOMER
// ========================================

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {
    header("Location: ../login.php");
    exit;
}

// ========================================
// AMBIL ID USER
// ========================================

$user_id = intval($_SESSION['id']);

// ========================================
// AMBIL DATA PESANAN USER
// ========================================

$query_orders = mysqli_query(
    $conn,
    "SELECT *
     FROM orders
     WHERE user_id = '$user_id'
     ORDER BY tanggal_pesanan DESC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Pesanan Saya - ChocoLush</title>

    <link rel="stylesheet"
        href="../assets/css/style.css">
</head>

<body>

<!-- ========================================
     NAVBAR
======================================== -->

<nav class="navbar">

    <div class="logo">
        🍫 ChocoLush
    </div>

    <div class="menu">

        <a href="user.php">
            Home
        </a>

        <a href="user.php#produk">
            Produk
        </a>

        <a href="keranjang.php">
            🛒 Keranjang
        </a>

        <a href="pesanan.php" class="active">
            📦 Pesanan Saya
        </a>

        <a href="../logout.php">
            Logout
        </a>

    </div>

</nav>


<!-- ========================================
     RIWAYAT PESANAN
======================================== -->

<section class="pesanan-section">

    <div class="pesanan-container">

        <div class="pesanan-title">

            <h1>
                📦 Pesanan Saya
            </h1>

            <p>
                Lihat riwayat dan status pesanan kamu
            </p>

        </div>


        <?php if (mysqli_num_rows($query_orders) > 0) { ?>

            <div class="pesanan-list">

                <?php while ($order = mysqli_fetch_assoc($query_orders)) { ?>

                    <?php

                    // ========================================
                    // AMBIL DETAIL PRODUK PESANAN
                    // ========================================

                    $order_id = intval($order['id']);

                    $query_details = mysqli_query(
                        $conn,
                        "SELECT
                            od.jumlah,
                            od.harga,
                            od.subtotal,
                            p.nama_produk,
                            p.gambar
                         FROM order_details od
                         LEFT JOIN products p
                            ON od.product_id = p.id
                         WHERE od.order_id = '$order_id'"
                    );

                    // Status untuk class CSS
                    $status_class = strtolower(
                        str_replace(
                            ' ',
                            '-',
                            $order['status']
                        )
                    );

                    ?>

                    <!-- ========================================
                         CARD PESANAN
                    ======================================== -->

                    <div class="pesanan-card">

                        <!-- HEADER PESANAN -->

                        <div class="pesanan-header">

                            <div>

                                <h2>
                                    Pesanan #<?php echo $order['id']; ?>
                                </h2>

                                <p>
                                    <?php
                                    echo date(
                                        'd F Y, H:i',
                                        strtotime($order['tanggal_pesanan'])
                                    );
                                    ?>
                                </p>

                            </div>


                            <span class="status-pesanan status-<?php echo $status_class; ?>">
                                <?php echo htmlspecialchars($order['status']); ?>
                            </span>

                        </div>


                        <!-- PRODUK -->

                        <div class="pesanan-produk">

                            <?php while ($detail = mysqli_fetch_assoc($query_details)) { ?>

                                <div class="pesanan-item">

                                    <div class="pesanan-gambar">

                                        <?php if (!empty($detail['gambar'])) { ?>

                                            <img
                                                src="../assets/img/produk/<?php echo htmlspecialchars($detail['gambar']); ?>"
                                                alt="<?php echo htmlspecialchars($detail['nama_produk']); ?>"
                                            >

                                        <?php } else { ?>

                                            🍫

                                        <?php } ?>

                                    </div>


                                    <div class="pesanan-info">

                                        <h3>
                                            <?php
                                            echo htmlspecialchars(
                                                $detail['nama_produk'] ?? 'Produk'
                                            );
                                            ?>
                                        </h3>

                                        <p>
                                            <?php echo $detail['jumlah']; ?>
                                            ×
                                            Rp
                                            <?php
                                            echo number_format(
                                                $detail['harga'],
                                                0,
                                                ',',
                                                '.'
                                            );
                                            ?>
                                        </p>

                                    </div>


                                    <strong>
                                        Rp
                                        <?php
                                        echo number_format(
                                            $detail['subtotal'],
                                            0,
                                            ',',
                                            '.'
                                        );
                                        ?>
                                    </strong>

                                </div>

                            <?php } ?>

                        </div>


                        <!-- ALAMAT & PEMBAYARAN -->

                        <div class="pesanan-detail">

                            <div>

                                <span>
                                    📍 Alamat Pengiriman
                                </span>

                                <p>
                                    <?php
                                    echo nl2br(
                                        htmlspecialchars($order['alamat'])
                                    );
                                    ?>
                                </p>

                            </div>


                            <div>

                                <span>
                                    💳 Pembayaran
                                </span>

                                <p>
                                    <?php
                                    echo htmlspecialchars(
                                        $order['metode_pembayaran']
                                    );
                                    ?>
                                </p>

                            </div>

                        </div>


                        <!-- TOTAL -->

                        <div class="pesanan-footer">

                            <span>
                                Total Pesanan
                            </span>

                            <strong>
                                Rp
                                <?php
                                echo number_format(
                                    $order['total_harga'],
                                    0,
                                    ',',
                                    '.'
                                );
                                ?>
                            </strong>

                        </div>

                    </div>

                <?php } ?>

            </div>


        <?php } else { ?>

            <!-- ========================================
                 BELUM ADA PESANAN
            ======================================== -->

            <div class="pesanan-kosong">

                <div class="pesanan-kosong-icon">
                    🛍️
                </div>

                <h2>
                    Belum Ada Pesanan
                </h2>

                <p>
                    Kamu belum memiliki riwayat pesanan.
                </p>

                <a href="user.php">
                    🍫 Mulai Belanja
                </a>

            </div>

        <?php } ?>

    </div>

</section>

</body>
</html>