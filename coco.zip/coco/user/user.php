<?php

session_start();

include "../config/database.php";


// Cek login customer
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {

    header("Location: ../login.php");
    exit;

}


// Ambil semua produk
$products = mysqli_query(
    $conn,
    "SELECT * FROM products ORDER BY id DESC"
);

// ========================================
// MENU FAVORIT
// ========================================

$query_menu_favorit = mysqli_query(
    $conn,
    "SELECT 
        p.id,
        p.nama_produk,
        p.harga,
        p.gambar,
        SUM(od.jumlah) AS total_terjual
     FROM order_details od
     INNER JOIN products p
        ON od.product_id = p.id
     INNER JOIN orders o
        ON od.order_id = o.id
     WHERE o.status != 'Dibatalkan'
     GROUP BY p.id
     ORDER BY total_terjual DESC
     LIMIT 4"
);
?>

<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        ChocoLush - Home
    </title>

    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >

</head>


<body>


<!-- =========================
     NAVBAR
========================= -->

<nav class="navbar">


    <div class="logo">
        🍫 ChocoLush
    </div>


    <div class="menu">

        <a href="user.php">
            Home
        </a>

        <a href="#produk">
            Produk
        </a>

        <a href="keranjang.php">
            🛒 Keranjang
        </a>

        <a href="pesanan.php">
            📦 Pesanan Saya
        </a>

        <a href="#">
            Profile
        </a>

        <a href="../logout.php">
            Logout
        </a>

    </div>


</nav>



<!-- =========================
     PESAN BERHASIL
========================= -->

<?php if (isset($_GET['berhasil'])) { ?>

    <div class="success-message">

        ✓ Produk berhasil ditambahkan ke keranjang!

    </div>

<?php } ?>



<!-- =========================
     HERO
========================= -->

<section class="hero">

    <div>

        <h1>
            Sweet Chocolate
            For Every Moment 🍫
        </h1>


        <p>
            Nikmati berbagai macam produk
            cokelat lezat dari ChocoLush.
        </p>


        <a
            href="#produk"
            class="hero-button"
        >
            Belanja Sekarang
        </a>

    </div>

</section>



<!-- =========================
     PRODUK
========================= -->

<section
    class="products"
    id="produk"
>


    <h2>
        Produk ChocoLush
    </h2>


    <p class="product-subtitle">
        Pilihan cokelat lezat untuk menemani
        setiap momen kamu.
    </p>



    <div class="product-container">


        <?php

        if (mysqli_num_rows($products) > 0) {

            while ($product = mysqli_fetch_assoc($products)) {

        ?>


            <!-- PRODUCT CARD -->

            <div class="product-card">


                <!-- GAMBAR -->

                <div class="product-image">


                    <?php if (!empty($product['gambar'])) { ?>

                        <img
                            src="../assets/img/produk/<?php echo htmlspecialchars($product['gambar']); ?>"
                            alt="<?php echo htmlspecialchars($product['nama_produk']); ?>"
                        >

                    <?php } else { ?>

                        <span>
                            🍫
                        </span>

                    <?php } ?>


                </div>



                <!-- NAMA -->

                <h3>

                    <?php echo htmlspecialchars(
                        $product['nama_produk']
                    ); ?>

                </h3>



                <!-- DESKRIPSI -->

                <p>

                    <?php

                    $deskripsi =
                        $product['deskripsi'];

                    if (strlen($deskripsi) > 80) {

                        echo htmlspecialchars(
                            substr($deskripsi, 0, 80)
                        ) . "...";

                    } else {

                        echo htmlspecialchars(
                            $deskripsi
                        );

                    }

                    ?>

                </p>



                <!-- HARGA -->

                <h4>

                    Rp <?php echo number_format(
                        $product['harga'],
                        0,
                        ',',
                        '.'
                    ); ?>

                </h4>



                <!-- STOK -->

                <p class="stock">

                    Stok:
                    <?php echo $product['stok']; ?>

                </p>



                <!-- BUTTON -->

                <div class="product-buttons">


                    <a
                        href="detail_produk.php?id=<?php echo $product['id']; ?>"
                        class="btn-detail"
                    >
                        Lihat Detail
                    </a>


                    <?php if ($product['stok'] > 0) { ?>

                        <a
                            href="detail_produk.php?id=<?php echo $product['id']; ?>"
                            class="btn-buy"
                        >
                            🛒 Tambah
                        </a>

                    <?php } else { ?>

                        <button
                            class="btn-disabled"
                            disabled
                        >
                            Stok Habis
                        </button>

                    <?php } ?>


                </div>


            </div>


        <?php

            }

        } else {

        ?>


            <div class="empty-product">

                <h3>
                    Belum ada produk
                </h3>

                <p>
                    Produk ChocoLush belum tersedia.
                </p>

            </div>


        <?php

        }

        ?>


    </div>

</section>


<!-- ========================================
     MENU FAVORIT
======================================== -->

<section class="menu-favorit">

    <div class="menu-favorit-container">

        <div class="menu-favorit-title">

            <h2>⭐ Menu Favorit</h2>

            <p>
                Produk yang paling banyak disukai customer
            </p>

        </div>


        <div class="favorit-container">

            <?php if (mysqli_num_rows($query_menu_favorit) > 0) { ?>

                <?php while ($favorit = mysqli_fetch_assoc($query_menu_favorit)) { ?>

                    <div class="favorit-card">

                        <div class="favorit-image">

                            <?php if (!empty($favorit['gambar'])) { ?>

                                <img
                                    src="../assets/img/produk/<?php echo htmlspecialchars($favorit['gambar']); ?>"
                                    alt="<?php echo htmlspecialchars($favorit['nama_produk']); ?>"
                                >

                            <?php } else { ?>

                                🍫

                            <?php } ?>

                        </div>


                        <div class="favorit-info">

                            <h3>
                                <?php echo htmlspecialchars($favorit['nama_produk']); ?>
                            </h3>

                            <p class="favorit-terjual">
                                ⭐ <?php echo $favorit['total_terjual']; ?>
                                terjual
                            </p>

                            <h4>
                                Rp <?php echo number_format(
                                    $favorit['harga'],
                                    0,
                                    ',',
                                    '.'
                                ); ?>
                            </h4>

                            <a
                                href="detail_produk.php?id=<?php echo $favorit['id']; ?>"
                                class="btn-favorit"
                            >
                                Lihat Produk
                            </a>

                        </div>

                    </div>

                <?php } ?>

            <?php } else { ?>

                <div class="favorit-empty">

                    <p>
                        Belum ada produk favorit.
                    </p>

                </div>

            <?php } ?>

        </div>

    </div>

</section>



<!-- =========================
     FOOTER
========================= -->

<footer class="footer">

    <h3>
        Tentang Kami
    </h3>

    <p>
        ChocoLush adalah usaha dessert yang memnghadirkan perpaduan cokelat leleh, buah-buahan segar,
        dan kunafa crispy dalam satu sajian yang lezat dan menarik. 
    </p>

    <p>
        Kami hadir untuk memberikan pengalaman meenikmati dessert yang tidak hanya enak, tetapi juga fresh, crunchy, creamy, dan 
        cocok dinikmati kapan saja
        
    </p>
    <p>
        Setiap menu di buat dengan bahan pilihan dan dikemas secara praktis sehingga dapat dinikmati sendiri maupun bersama orang terdekat
    </p>
    <p>
        © 2026 ChocoLush
    </p>

</footer>


</body>

</html>